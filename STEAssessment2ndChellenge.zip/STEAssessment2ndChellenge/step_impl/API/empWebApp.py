import os
from getgauge.python import Messages
import requests

class EmpBeneAppClient(object):
    def __init__(self, id="", firstname="", lastname="", access_token=""):
        """Create a REST Client to simulate a mobile app."""
        self.id = id
        self.firstname = firstname
        self.lastname = lastname
        self.access_token = access_token
    
    def _getBaseUrl(self):
            return os.getenv('prod')

    def _getHeaders(self):
        headers = {
            'Accept': 'application/json',
            'Content-type': 'application/json'
        }
        if self.access_token is not None:
            headers['Authorization'] = "Basic " + self.access_token
        return headers

    def _apiRequest(self, method, endpoint, jsonObj=None):
        baseurl = self._getBaseUrl()
        url = baseurl + endpoint
        headers = self._getHeaders()

        req = requests.Request(method=method, url=url, params=None, json=jsonObj, headers=headers)
        prepared = req.prepare()
        self._log_request(prepared)

        s = requests.Session()
        response = s.send(prepared, verify=False)
        self._log_response(response)

        return response

    def _log_request(self, req):
        Messages.write_message('\n<b>{} {}</b>'.format(req.method, req.url))
        Messages.write_message('\n<i>Request Headers:</i>')
        Messages.write_message('\n'.join('{}: {}'.format(k, v) for k, v in req.headers.items()))
        Messages.write_message('\n<i>Request Body:</i>')
        Messages.write_message('{}'.format(req.body))

    def _log_response(self, res):
        Messages.write_message('\n---Response---')
        Messages.write_message('<i>Status code:</i> <b>{}</b>'.format(res.status_code))
        Messages.write_message('\n<i>Response Headers:</i>')
        Messages.write_message('\n'.join('{}: {}'.format(k, v) for k, v in res.headers.items()))
        if res.status_code != requests.codes.no_content:
            Messages.write_message('\n<i>Response Body:</i>')
            Messages.write_message('{}'.format(res.json()))

    def request_token(self, password):
        json = {'username': self.email, 'password': password}
        response = self._apiRequest(method='POST', endpoint='/Prod/api/employees?token', jsonObj=json)
        json = response.json()
        self.access_token = json
        
    def get_emp_bene_info(self):
        response = self._apiRequest(method='GET',endpoint='/Prod/api/employees/' )
        json = response.json()
        return json
import os
from getgauge.python import before_suite, after_suite, step
from selenium import webdriver
from uuid import uuid1
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC 
from selenium.webdriver.common.action_chains import ActionChains



class Driver:
    instance = None

@before_suite
def init(parser):
    global driver
    Driver.instance = webdriver.Chrome(executable_path="C:\\Users\\SRATHAMA\\standupgs\\go_gauge_demo\\webdrivers\\chromedriver.exe")

@after_suite
def close():
    Driver.instance.close()
    # pass


@step("Navigate to <environment>")
def navigate_to(environment):
    if environment == "prod":
        url = "https://wmxrwq14uc.execute-api.us-east-1.amazonaws.com/Prod/Account/Login"
    elif environment == "test":
        url = "https://wmxrwq14uc.execute-api.us-east-1.amazonaws.com/Test/Account/Login"
    
    Driver.instance.get(url)
    time.sleep(10)
    

@step("Login using <username>")
def login(username):
    # Enter Username
    # Driver.instance.switch_to.frame('login')
    input_username = WebDriverWait(Driver.instance, 10).until(
                EC.visibility_of_element_located((By.XPATH,'//input[@id="Username"]'))
            )
    input_username.send_keys(username)
    
    # Enter Password  
    input_password = WebDriverWait(Driver.instance, 5).until(
                EC.visibility_of_element_located((By.XPATH,'//input[@id="Password"]'))
            )
    time.sleep(5)
    input_password.send_keys('!Qq$kwS[^]&h')
    
    #time.sleep(10)
    btn_Login = Driver.instance.find_element(By.XPATH,'//button[contains(text(),"Log In")]')
    btn_Login.click()
    time.sleep(5)
#@step("Add Employee")
#def addEmployee( ):
    # Use the 4 loop to add 4 employees
    for i in range(3):
        if i <= 3:
            
            # Click on the Add Employee button
            btn_AddEmp = Driver.instance.find_element(By.XPATH,'//button[@id="add"]')
            btn_AddEmp.click()
        
            time.sleep(5)
            # Verify the Add Employee form appears
            WebDriverWait(Driver.instance, 5).until(
            EC.visibility_of_element_located((By.XPATH,'//*[@id="employeeModal"]/div/div'))
            )
            print('Add Employee form appears')

            input_empfirstname = WebDriverWait(Driver.instance, 5).until(
            EC.visibility_of_element_located((By.XPATH,'//*[@id="firstName"]'))
            )
            print('First Name field is displayed')
            
            input_empfirstname.send_keys('Princess', (++1))
            
           
            input_emplastname = WebDriverWait(Driver.instance, 5).until(
            EC.visibility_of_element_located((By.XPATH,'//*[@id="lastName"]'))
            )
            print('Last Name field is displayed')
            input_emplastname.send_keys('Buttercup', (++1))
           
            input_empdependant = WebDriverWait(Driver.instance, 5).until(
            EC.visibility_of_element_located((By.XPATH,'//*[@id="dependants"]'))
            )
            print('Dependant field is displayed')
            input_empdependant.send_keys('2')
            
            # Enter Employee Firs Name, Last Name and Dependants
            time.sleep(5)
            # Click Add to save an employee
            btn_addEmployee = Driver.instance.find_element(By.XPATH,'//*[@id="addEmployee"]')
            btn_addEmployee.click()
            time.sleep(5)
            continue
    # Remove an employee
    btn_removeEmployee = Driver.instance.find_element(By.XPATH,'//*[@id="employeesTable"]/tbody/tr[1]/td[9]/i[2]')
    btn_removeEmployee.click()
    # Verify the Delete Employee confirmation appears
    WebDriverWait(Driver.instance, 5).until(
    EC.visibility_of_element_located((By.XPATH,'//*[@id="deleteModal"]/div/div'))
    )
    print('Delete confirmation appears')
    # Delet an employee
    btn_deleteEmployee = Driver.instance.find_element(By.XPATH,'//*[@id="deleteEmployee"]')
    btn_deleteEmployee.click()
    
    #Driver.instance.find_element(By.XPATH,'//*[text()="No employees found."]')
 
@step("Logout")
def logout():
    
        btn_logout = WebDriverWait(Driver.instance, 10).until(
                EC.visibility_of_element_located((By.XPATH,'//*[text()="Log Out"]'))
            )
        btn_logout.click()

